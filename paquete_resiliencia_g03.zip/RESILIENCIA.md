# Resiliencia · G03 · Quién crece y quién se muere

![Estado del robot](https://github.com/uide-programacion-inteligencia-mercados/observatorio-g03/actions/workflows/orquestador_diario.yml/badge.svg)

La insignia de arriba dice si la última corrida del robot terminó bien (verde) o mal (rojo).

## Las reglas de calidad del robot
| Indicador | Mínimo creíble | Máximo creíble |
|---|---|---|
| Crecimiento del PIB (%) | -12.0 | 12.0 |
| Crecimiento de los servicios (%) | -12.0 | 12.0 |

- Filas mínimas: 12 · Antigüedad máxima del último dato: 3 años
- Reintentos: 4, con espera inicial de 3 s que se duplica en cada intento
- Reloj: `15 11 * * *`

## Qué es una falla para nosotros
Cuenta como falla recibir datos fuera del rango de -15% a 15%, menos de 10 filas o datos viejos, porque evitaremos mostrar información corrupta o atípica en el tablero

## Nuestro plan B
Si la API no contesta, el robot realiza 3 reintentos con espera exponencial; si persiste el fallo, genera una alerta y conserva los datos anteriores para no borrar el tablero.

## Quién atiende la alerta
El encargado del observatorio atiende la alerta y lo primero que revisa es la bitácora de ejecución para verificar si la API estuvo caída o si llegaron datos anómalos.

## Qué vigilamos cada lunes
Vigilamos la columna de estado y tiempo de respuesta en salud_g03.csv para asegurar que las corridas se completen en verde y detectar reintentos inusuales.
